.. Rocket documentation master file, created by
   sphinx-quickstart on Fri Nov 27 17:53:20 2009.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

==================================
Welcome to Rocket's documentation!
==================================

.. toctree::
   :maxdepth: 2

   usage
   methods
   design
   extras
   development
   acknowledgements
   license

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
